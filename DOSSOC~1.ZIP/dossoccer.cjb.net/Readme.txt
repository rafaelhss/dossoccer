DOS Socccer    ver 1.81

Instala��o :

   Basta rodar o arquivo "DosSoccer.exe" direto da pasta na qual voce
deszipou o arquivo baixado. Aten��o! N�o deixe o arquivo "Dossoccer.exe"
em uma pasta diferente dos arquivos "data.fut" , ou o programa n�o
funcionar�. Ambos devem estar da mesma pasta.


Como jogar:

   Escolha suas opcoes e a��es digitando os numeros correspondentes e em
seguida <ENTER> . Nunca digite qualquer outro tipo de caracter que n�o
numeros. isso causa um erro e voce ser� obrigado a sair do programa.
portanto, digite apenas algarismos.


Jogo:

    O jogo come�a na fase classificatoria da UCL com quatro equipes
em cada grupo. Classificam-se as duas melhores equipes de cada 
grupo. Sao jogos apenas de ida.
    Na fase eliminatoria, se as equipes empatarem no tempo normal, 
haver� disputa de penaltis.
    A equipe campe� tem o direito de disputar o titulo mundial
interclubes em Tokio contra uma equipe sulamericana.
    Se conseguir 100% de aproveitamento, ter� uma surpresa . . . . 


BOM DIVERTIMENTO!!!
	
	Fa�a o download das escala�oes atualizadas 
 no nosso site periodicamente

entre em contato para mais novidades

			FrUbBs TeChNoLoGy inc.
			rafa@coelhao.com.br
                    http://www.dossoccer.cjb.net
		

 